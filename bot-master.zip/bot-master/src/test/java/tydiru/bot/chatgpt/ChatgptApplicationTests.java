package tydiru.bot.chatgpt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatgptApplicationTests {

    @Test
    void contextLoads() {
    }

}
